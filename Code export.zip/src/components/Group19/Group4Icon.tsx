import { memo, SVGProps } from 'react';

const Group4Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 40 51' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <rect x={14.1181} width={4.7535} height={50.1278} fill='#D9D9D9' />
    <rect width={4.7535} height={50.1278} fill='#D9D9D9' />
    <path d='M26.2362 0L39.2003 8.42666V50.1278H26.2362V0Z' fill='#D9D9D9' />
  </svg>
);

const Memo = memo(Group4Icon);
export { Memo as Group4Icon };
