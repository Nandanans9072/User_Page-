import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import { Ellipse3Icon } from './Ellipse3Icon.js';
import { Ellipse4Icon } from './Ellipse4Icon.js';
import { Ellipse5Icon } from './Ellipse5Icon.js';
import { Ellipse6Icon } from './Ellipse6Icon.js';
import { Group4Icon } from './Group4Icon.js';
import classes from './Group19.module.css';
import { Polygon1Icon } from './Polygon1Icon.js';

interface Props {
  className?: string;
}
/* @figmaId 23:67 */
export const Group19: FC<Props> = memo(function Group19(props = {}) {
  return (
    <>
      <div className={classes.frame1}>
        <div className={classes.unnamed}>...</div>
        <div className={classes.unnamed2}>...</div>
        <div className={classes.frame2}>
          <div className={classes.rectangle3}></div>
          <div className={classes.home}>Home</div>
          <div className={classes.search}>Search</div>
          <div className={classes.search2}></div>
        </div>
        <div className={classes.rectangle35}></div>
        <div className={classes.rectangle1}></div>
        <div className={classes.rectangle2}></div>
        <div className={classes.yourLibrary}>Your Library</div>
        <div className={classes.rectangle4}></div>
        <div className={classes.rectangle5}></div>
        <div className={classes.rectangle6}></div>
        <div className={classes.group4}>
          <Group4Icon className={classes.icon} />
        </div>
        <div className={classes.playlist}>Playlist</div>
        <div className={classes.albums}>Albums</div>
        <div className={classes.artists}>Artists</div>
        <div className={classes.rectangle16}></div>
        <div className={classes.rectangle17}></div>
        <div className={classes.search3}></div>
        <div className={classes.recents}>Recents</div>
        <div className={classes.polygon1}>
          <Polygon1Icon className={classes.icon2} />
        </div>
        <div className={classes.image3}></div>
        <div className={classes.edSheeran}>Ed Sheeran</div>
        <div className={classes.image4}></div>
        <div className={classes._87630755MonthlyListeners}>
          <p className={classes.labelWrapper}>
            <span className={classes.label}>87,630,755</span>
            <span className={classes.label2}> monthly listeners</span>
          </p>
        </div>
        <div className={classes.ellipse4}>
          <Ellipse4Icon className={classes.icon3} />
        </div>
        <div className={classes.ellipse5}>
          <Ellipse5Icon className={classes.icon4} />
        </div>
        <div className={classes.ellipse3}>
          <Ellipse3Icon className={classes.icon5} />
        </div>
        <div className={classes.rectangle18}></div>
        <div className={classes.rectangle19}></div>
        <div className={classes.rectangle192}></div>
        <div className={classes.rectangle21}></div>
        <div className={classes.rectangle22}></div>
        <div className={classes.likedSongs}>Liked Songs</div>
        <div className={classes.starboy}>Starboy</div>
        <div className={classes.dreamland}>Dreamland</div>
        <div className={classes.albumsGlassAnimals}>
          <p className={classes.labelWrapper2}>
            <span className={classes.label3}>Albums</span>
            <span className={classes.label4}> </span>
            <span className={classes.label5}>.</span>
            <span className={classes.label6}> </span>
            <span className={classes.label7}>Glass Animals</span>
          </p>
        </div>
        <div className={classes.albumsTheWeekend}>
          <p className={classes.labelWrapper3}>
            <span className={classes.label8}>Albums</span>
            <span className={classes.label9}> </span>
            <span className={classes.label10}>.</span>
            <span className={classes.label11}> The Weekend</span>
          </p>
        </div>
        <div className={classes.playlist20Songs}>
          <p className={classes.labelWrapper4}>
            <span className={classes.label12}>Playlist </span>
            <span className={classes.label13}>.</span>
            <span className={classes.label14}> 20 songs </span>
          </p>
        </div>
        <div className={classes.rectangle23}></div>
        <div className={classes.rectangle24}></div>
        <div className={classes.ellipse6}>
          <Ellipse6Icon className={classes.icon6} />
        </div>
        <div className={classes.image10}></div>
        <div className={classes.rectangle25}></div>
        <div className={classes.fOLLOW}>FOLLOW</div>
        <div className={classes.popular}>Popular</div>
        <div className={classes._1}>1</div>
        <div className={classes._2}>2</div>
        <div className={classes.image11}></div>
        <div className={classes.eyesClosed}>Eyes Closed</div>
        <div className={classes._314}>3:14</div>
        <div className={classes._423}>4:23</div>
        <div className={classes.image12}></div>
        <div className={classes.perfect}>Perfect</div>
        <div className={classes.rectangle26}></div>
        <div className={classes.end}></div>
        <div className={classes.rectangle28}></div>
        <div className={classes._0}>0:00</div>
        <div className={classes._02}>0:00</div>
        <div className={classes.rectangle29}></div>
        <div className={classes.rectangle32}></div>
        <div className={classes.rectangle31}></div>
        <div className={classes.image14}></div>
        <div className={classes.image13}></div>
        <div className={classes.rectangle33}></div>
        <div className={classes.rectangle34}></div>
        <div className={classes.image16}></div>
        <div className={classes.image17}></div>
        <div className={classes.rectangle36}></div>
        <div className={classes.rectangle37}></div>
      </div>
      <div className={classes.verifiedArtists}>
        <p className={classes.labelWrapper5}>
          <span className={classes.label15}>Verified Artists</span>
          <span className={classes.label16}> </span>
        </p>
      </div>
      <div className={classes.playButtonCircled}></div>
      <div className={classes.end2}></div>
    </>
  );
});
