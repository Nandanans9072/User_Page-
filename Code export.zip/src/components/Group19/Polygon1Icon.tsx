import { memo, SVGProps } from 'react';

const Polygon1Icon = (props: SVGProps<SVGSVGElement>) => (
  <svg preserveAspectRatio='none' viewBox='0 0 39 24' fill='none' xmlns='http://www.w3.org/2000/svg' {...props}>
    <path d='M19.0941 24.0001L2.55812 6.00005L35.63 6.00005L19.0941 24.0001Z' fill='#717171' />
  </svg>
);

const Memo = memo(Polygon1Icon);
export { Memo as Polygon1Icon };
